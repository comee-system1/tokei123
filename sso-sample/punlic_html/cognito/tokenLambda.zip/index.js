const jwkToPem = require("jwk-to-pem");
const jwt = require("jsonwebtoken");

// ユーザープールURL
// https://cognito-idp.{リージョン}.amazonaws.com/{プールID}
const userPoolUrl =
  "https://cognito-idp.us-east-2.amazonaws.com/us-east-2_CZErrRbBU";

// アプリクライアントIDリスト
const clients = require("./clients.json");

// 公開キーリスト
const jwks = require("./jwks.json");
// JWT正規表現
const jwtRe = /(?<header>.+)\.(?<payload>.+)\.(?<signature>.+)/;

exports.handler = async (event) => {
  // event情報からIDトークンを取得
  const token = event.headers["authorization"];

  // トークンの形式チェック
  const sections = jwtRe.exec(token);
  if (!sections) {
    console.log("token format error");
    return {
      statusCode: 401,
      body: JSON.stringify({ error: "Unauthorized." }),
    };
  }

  // トークンのヘッダー情報取得
  const header = JSON.parse(
    Buffer.from(sections.groups.header, "base64").toString()
  );

  // 公開キーリストから該当するキーを取得
  const jwk = jwks.keys.find((k) => k.kid == header.kid);
  if (!jwk) {
    console.log("token header error");
    return {
      statusCode: 401,
      body: JSON.stringify({ error: "Unauthorized." }),
    };
  }

  // pem形式の証明書に変換
  const pem = jwkToPem(jwk);

  try {
    // トークンデコード
    const decodedToken = jwt.verify(token, pem, { issuer: userPoolUrl });

    // 有効期限、発行元URLが不正等の場合はerrorがthrowされる

    console.log("decoded id token:");
    console.log(decodedToken);

    // トークンタイプの確認
    if (decodedToken.token_use !== "id") {
      // id tokenでない場合エラー
      console.log("Incorrect token type");
      return {
        statusCode: 401,
        body: JSON.stringify({ error: "Invalid token type." }),
      };
    }

    // アプリクライアントの確認
    if (clients.apps.find((c) => c.id !== decodedToken.aud)) {
      console.log("Incorrect client id");
      return {
        statusCode: 401,
        body: JSON.stringify({ error: "Incorrect client id." }),
      };
    }

    // トークンの検証にエラーがなければデコードした情報を返却
    return {
      statusCode: 200,
      body: JSON.stringify(decodedToken),
    };
  } catch (err) {
    console.log(err);

    // トークン有効期限切れ
    if (err.name === "TokenExpiredError") {
      return {
        startusCode: 401,
        body: JSON.stringify({
          error: "token expired",
          expired: err.expiredAt,
        }),
      };
    }

    // その他のエラー
    return {
      statusCode: 401,
      body: JSON.stringify({ error: err.name, message: err.message }),
    };
  }
};
