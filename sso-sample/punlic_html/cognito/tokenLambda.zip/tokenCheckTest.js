// tokenCheckTest.js
// id_token解析テスト
// 「node tokenCheckTest.js」でテスト可能

var jwkToPem = require('jwk-to-pem');
var jwt = require('jsonwebtoken');

// 公開キーリスト
const jwks = require('./jwks.json');
// JWT正規表現
const jwtRe = /(?<header>.+)\.(?<payload>.+)\.(?<signature>.+)/;

// id_token (本来はhttp headerから取得)
const token = 'eyJraWQiOiJpOEZuUUdzS2EramVcL2tFYTV3UkxNc0pIRUVQY2EyNjZrc0ZVYUl2ckFGND0iLCJhbGciOiJSUzI1NiJ9.eyJhdF9oYXNoIjoibEliMjVVMG1ha3Y0S2l1dmF1YXRkQSIsInN1YiI6IjI5ZDg4Y2E3LWEwMGUtNDAyMy04MjQ5LWRjYzZhYTNkMzRmNCIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0yLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMl9DWkVyclJiQlUiLCJwaG9uZV9udW1iZXJfdmVyaWZpZWQiOnRydWUsImNvZ25pdG86dXNlcm5hbWUiOiIyOWQ4OGNhNy1hMDBlLTQwMjMtODI0OS1kY2M2YWEzZDM0ZjQiLCJhdWQiOiI2MW9jYWtrcTF0OHA3bmIzbGNtZDJybDg5MyIsImV2ZW50X2lkIjoiNjQ2ZmRjZDAtZDlhNS00YzFjLTk5NzgtMjk5Mjk2NDA1ZmFkIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE2MDg2OTQ4MDIsInBob25lX251bWJlciI6Iis4MTEyMzQ1Njc4OSIsImV4cCI6MTYwODc4MTIwMiwiaWF0IjoxNjA4Njk0ODAyLCJlbWFpbCI6ImNvZ25pdG9fc2FtcGxlQHRlc3QuY29tIn0.EEzT6MGXihaQVfB2EOlGcWBUhJpcvdKkrNA_K0IIsvwYoaJPYq55xwim5gKeLTbwkxJ1pXJBhw2vXMQhjI4fV2mEV6Sq3Pak1Vimx6HqGmuHJxeh9gYbooERhrgz9nK7cn4uIz7_9kltdF8w1XSwPbJoMv46_JIus5jMT-51m0_iCjpeFOQUv7dtHYRka6qJatLTwrrNfk-iBb3sGipQAIKPc8zvlikfc17x_NJhAzMKsMpMqm5gCuxo1iwxcDBBpUvgFr-6i2lNH2H3UP3Vdx77tyqlSy0kztLWrj2trfz2G-gZu0wuTn64o-hg0ZDagdFmiqBudcIy8VOfQeT-Fg';

try {
    var sections = jwtRe.exec(token);
    if (!sections) {
        // id_tokenの形式が間違っている場合
        throw new Error('Incorrect id token format.');
    }
    // id_tokenのheaderをデコード
    const token_header = JSON.parse(Buffer.from(sections.groups.header, 'base64').toString());
    // 公開キーリストから使用するキーを取得
    const jwk = jwks.keys.find(k => k.kid == token_header.kid);
    if (!jwk) {
        // 不正なキーのid_tokenの場合
        console.log('id_token public key: ' + token_header.kid);
        throw new Error('auth error');
    }
    // pem形式の証明書に変換
    const pem = jwkToPem(jwk);
    // pemを使用してtokenをデコード
    const decodedToken = jwt.verify(token, pem, function(err, decodedToken){
        if (err) {
            throw new Error(err);
        }
        console.log(decodedToken);
    });
} catch (e) {
    console.log(e.message);
}