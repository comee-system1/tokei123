var mysql = require('mysql');
var bcrypt = require('bcrypt');

exports.handler = function (event, context, callback) {
    var user;
    if (event.triggerSource == "UserMigration_Authentication") {
        // cognitoのユーザー認証に失敗した場合、以下実行

        // 外部DBに接続
        var connection = connectDb();

        // 入力されたemailでユーザー検索
        var sql = 'SELECT * FROM users WHERE email = ?';
        connection.query(sql, [event.userName], function(err, rows, fields) {
            // SQLの実行に失敗した場合
            if (err) {
                context.done('sql error', err);
            }
            
            // 登録されていない場合
            if (rows.length === 0) {
                console.log('Bad Email');
                callback('Bad Email');
            }
            
            // 登録されている場合、passwordチェック
            user = rows[0];
            
            // Laravel（TWGログインサンプルサイト）で生成するハッシュタイプのプレフィックスは「$2Y$」。
            // node (Auth0)で生成するハッシュタイプのプレフィックスは「$2b$」。
            // プレフィックスのみ置き換えしてパスワード検証する。
            user['password'] = user['password'].replace('$2y$', '$2b$');
            bcrypt.compare(event.request.password, user['password'], function (err, isValid) {
                if (err) {
                    // パスワードの検証に失敗した場合
                    console.log('error password check');
                    context.done('password check error', err);
                } else if (!isValid) {
                    // パスワードが間違っている場合
                    console.log('Bad Password');
                    callback('Bad Password');
                } else {
                    // パスワードの検証に成功した場合
                    console.log('Success password');
                    
                    // cognitoにアカウント登録
                    event.response.userAttributes = {
                        "name": user['name'],
                        "email": user['email'],
                        "email_verified": "true"
                    };
                    event.response.finalUserStatus = "CONFIRMED";
                    event.response.messageAction = "SUPPRESS";
                    context.succeed(event);
                }
            });
        });

        // DB接続解除
        closeDbConnect(connection);
    }
    else if (event.triggerSource == "UserMigration_ForgotPassword") {
        // cognitoのパスワードリセット時、入力したemailがcognitoユーザーデータにない場合、以下実行

        // 外部DBに接続
        var connection = connectDb();
        
        // 入力されたemailでユーザー検索
        var sql = 'SELECT * FROM users WHERE email = ?';
        connection.query(sql, [event.userName], function(err, rows, fields) {
            // SQLの実行に失敗した場合
            if (err) {
                context.done('sql error', err);
            }
            
            // 登録されていない場合
            if (rows.length === 0) {
                callback('Bad Email');
            }
            
            // 登録されている場合、cognitoにアカウント登録
            user = rows[0];
            event.response.userAttributes = {
                "name": user['name'],
                "email": user['email'],
                "email_verified": "true"  
            };
            event.response.messageAction = "SUPPRESS";
            context.succeed(event);
        });

        // DB接続解除
        closeDbConnect(connection);
    }
    else {
        // 上記以外のcognitoフローはエラー
        callback("Bad triggerSource " + event.triggerSource);
    }
};

// 外部DBに接続
function connectDb() {
    // DBの接続情報（外部からのアクセスを許可しておく）
    var mysql_host = "IPアドレス";
    var mysql_user = "DBユーザー名";
    var mysql_dbname = "DB名";
    var mysql_password = "DBパスワード";
    
    var connection = mysql.createConnection({
        host     : mysql_host,
        user     : mysql_user,
        password : mysql_password,
        database : mysql_dbname
    });
    connection.connect();
    return connection;
}

// 外部DBの接続解除
function closeDbConnect(connection) {
    connection.end(function(err) {
        if (err) {
            console.log('DB connection end error');
            console.log(err);
            return false;
        }
    });
    return true;
}