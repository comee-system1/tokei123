var bcrypt = require('bcrypt');

var dbpw = "$2y$10$U707TslvmOImjyIkOUJYguMcHtMADeDXcoKXZcieqMdImbNQhNiYC";  // DBから取得したハッシュ済みパスワード
var pw = "password";    // 入力したパスワード

// Laravel（TWGログインサンプルサイト）で生成するハッシュタイプのプレフィックスは「$2Y$」。
// node (Auth0)で生成するハッシュタイプのプレフィックスは「$2a$」。
// プレフィックスのみ置き換えしてパスワード検証する。
dbpw = dbpw.replace('$2y$', '$2b$');
bcrypt.compare(pw, dbpw, function (err, isValid) {
    // パスワードが間違っている
    if (err || !isValid) {
        console.log('Bad password');
    }
    else {
        console.log('success');
    }
});